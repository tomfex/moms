require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');
const path = require('path');
const siteConfig = require('./config/site');

const app = express();

// Middleware
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Security headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
});

// Routes
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/lead-capture', (req, res) => res.sendFile(path.join(__dirname, 'public', 'lead-capture.html')));
app.get('/checkout', (req, res) => res.sendFile(path.join(__dirname, 'public', 'checkout.html')));
app.get('/thank-you', (req, res) => res.sendFile(path.join(__dirname, 'public', 'thank-you.html')));

// API Routes
app.post('/api/subscribe', async (req, res) => {
    try {
        const { name, email, wantsCourseInfo } = req.body;
        
        // Here you would integrate with your email service
        // For example, Mailchimp, ConvertKit, etc.
        
        res.json({ success: true });
    } catch (error) {
        console.error('Subscription error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Stripe Checkout
app.post('/create-checkout-session', async (req, res) => {
    try {
        const { includeCoaching } = req.body;
        
        const lineItems = [{
            price_data: {
                currency: siteConfig.pricing.course.currency,
                product_data: {
                    name: siteConfig.pricing.course.name,
                    description: siteConfig.pricing.course.description,
                },
                unit_amount: siteConfig.pricing.course.amount,
            },
            quantity: 1,
        }];

        if (includeCoaching) {
            lineItems.push({
                price_data: {
                    currency: siteConfig.pricing.coaching.currency,
                    product_data: {
                        name: siteConfig.pricing.coaching.name,
                        description: siteConfig.pricing.coaching.description,
                    },
                    unit_amount: siteConfig.pricing.coaching.amount,
                },
                quantity: 1,
            });
        }

        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: lineItems,
            mode: 'payment',
            success_url: `${siteConfig.site.url}/thank-you?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${siteConfig.site.url}/checkout`,
            customer_email: req.body.email,
            metadata: {
                source: req.body.source || 'direct'
            }
        });

        res.json({ id: session.id });
    } catch (error) {
        console.error('Error creating checkout session:', error);
        res.status(500).json({ error: error.message });
    }
});

// Order details endpoint
app.get('/order-details', async (req, res) => {
    try {
        const session = await stripe.checkout.sessions.retrieve(
            req.query.session_id,
            { expand: ['line_items', 'customer'] }
        );
        
        res.json({
            customer: session.customer_details,
            amount: session.amount_total / 100,
            items: session.line_items.data.map(item => ({
                name: item.description,
                amount: item.amount_total / 100
            }))
        });
    } catch (error) {
        console.error('Error retrieving order details:', error);
        res.status(500).json({ error: error.message });
    }
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`)); 