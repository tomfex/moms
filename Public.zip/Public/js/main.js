document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Add animation to CTA button
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('mouseover', function() {
            this.style.transform = 'translateY(-3px)';
        });
        ctaButton.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });
    }

    // Track CTA button clicks
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            // Add your analytics tracking code here
            console.log('CTA button clicked');
        });
    }
}); 