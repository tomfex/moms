document.addEventListener('DOMContentLoaded', function() {
    // Fetch order details from backend
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');
    
    if(sessionId) {
        fetch(`/order-details?session_id=${sessionId}`)
            .then(response => response.json())
            .then(data => {
                // Update WhatsApp link with customer's phone number if available
                if (data.customer && data.customer.phone) {
                    const whatsappLink = document.querySelector('.whatsapp-cta');
                    whatsappLink.href = `https://wa.me/${data.customer.phone}`;
                }
                
                // Track successful purchase
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'purchase', {
                        transaction_id: sessionId,
                        value: data.amount,
                        currency: 'EUR',
                        items: data.items
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching order details:', error);
            });
    }

    // Add animation to WhatsApp CTA
    const whatsappCta = document.querySelector('.whatsapp-cta');
    if (whatsappCta) {
        whatsappCta.addEventListener('mouseover', function() {
            this.style.transform = 'translateY(-3px)';
        });
        whatsappCta.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });
    }
}); 