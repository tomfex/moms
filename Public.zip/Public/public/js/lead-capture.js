document.addEventListener('DOMContentLoaded', function() {
    const leadForm = document.getElementById('leadForm');
    
    leadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const submitButton = leadForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';
        
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            wantsCourseInfo: document.getElementById('course-info').checked
        };
        
        try {
            // Store email for checkout
            localStorage.setItem('userEmail', formData.email);
            
            // Send to your email service
            const response = await fetch('/api/subscribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            
            // Track conversion
            if (typeof gtag !== 'undefined') {
                gtag('event', 'generate_lead', {
                    currency: 'EUR',
                    value: 0.00
                });
            }
            
            // Redirect to checkout if they want course info
            if (formData.wantsCourseInfo) {
                window.location.href = '/checkout';
            } else {
                // Show success message
                leadForm.innerHTML = `
                    <div style="text-align: center; padding: 2rem;">
                        <h3 style="color: var(--secondary);">Thank You!</h3>
                        <p>Check your email for your free starter kit.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error:', error);
            submitButton.disabled = false;
            submitButton.textContent = 'GET FREE ACCESS NOW';
            
            // Show error message
            const errorDiv = document.createElement('div');
            errorDiv.style.color = 'var(--primary)';
            errorDiv.style.marginTop = '1rem';
            errorDiv.style.textAlign = 'center';
            errorDiv.textContent = 'Something went wrong. Please try again.';
            leadForm.appendChild(errorDiv);
        }
    });
}); 