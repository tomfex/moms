// Initialize Stripe
const stripe = Stripe('pk_test_your_publishable_key');
let elements;

// Initialize the payment form
async function initialize() {
    try {
        const response = await fetch("/create-checkout-session", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                includeCoaching: false,
                email: localStorage.getItem('userEmail') || ''
            }),
        });
        
        const { id: sessionId } = await response.json();
        
        const { clientSecret } = await fetch(`/create-payment-intent?session_id=${sessionId}`).then(r => r.json());
        
        elements = stripe.elements({ clientSecret });
        const paymentElement = elements.create("payment");
        paymentElement.mount("#payment-element");
    } catch (error) {
        console.error('Error initializing payment:', error);
        document.getElementById('error-message').textContent = 'Error loading payment form. Please try again.';
    }
}

// Handle form submission
document.getElementById("payment-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    const submitButton = document.getElementById('submit');
    submitButton.disabled = true;
    submitButton.textContent = 'Processing...';
    
    try {
        const { error } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: `${window.location.origin}/thank-you`,
            },
        });

        if (error) {
            document.getElementById("error-message").textContent = error.message;
            submitButton.disabled = false;
            submitButton.textContent = 'PAY NOW';
        }
    } catch (error) {
        console.error('Payment error:', error);
        document.getElementById("error-message").textContent = 'An unexpected error occurred. Please try again.';
        submitButton.disabled = false;
        submitButton.textContent = 'PAY NOW';
    }
});

// Handle coaching upsell
document.getElementById('coaching').addEventListener('change', async function() {
    try {
        const response = await fetch("/create-checkout-session", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                includeCoaching: this.checked,
                email: localStorage.getItem('userEmail') || ''
            }),
        });
        
        const { id: sessionId } = await response.json();
        window.location.href = `/checkout?session_id=${sessionId}`;
    } catch (error) {
        console.error('Error updating session:', error);
        document.getElementById('error-message').textContent = 'Error updating your order. Please try again.';
    }
});

// Initialize the payment form
initialize(); 