#!/bin/bash

# Build the project
echo "Building project..."
npm install

# Create production environment file
echo "Creating production environment..."
cp .env.example .env.production

# Create deployment package
echo "Creating deployment package..."
mkdir -p deploy
cp -r public/* deploy/
cp -r config deploy/
cp server.js deploy/
cp package.json deploy/
cp .env.production deploy/.env

# Compress files
echo "Compressing files..."
cd deploy
zip -r ../deploy.zip .

# Instructions for manual upload
echo "
Deployment package created: deploy.zip

To deploy to Hostinger:
1. Log in to your Hostinger control panel
2. Go to File Manager
3. Navigate to public_html
4. Upload deploy.zip
5. Extract the files
6. Set up Node.js in Hostinger:
   - Go to Advanced > Node.js
   - Enable Node.js
   - Set Node.js version to 18.x
   - Set application path to /public_html
   - Set application URL to your domain
   - Set startup file to server.js
7. Install dependencies:
   - Open SSH terminal in Hostinger
   - Run: cd public_html && npm install
8. Start the application:
   - In Node.js settings, click 'Start Application'

Remember to:
- Set up SSL certificate in Hostinger
- Configure domain DNS settings
- Set up environment variables in Hostinger's Node.js settings
"

# Cleanup
cd ..
rm -rf deploy 