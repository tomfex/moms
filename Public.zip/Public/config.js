const config = {
    site: {
        name: 'Mom AI',
        url: 'https://mom-ai.shop',
        description: 'AI Solutions for Busy Moms',
        email: 'contact@mom-ai.shop'
    },
    social: {
        facebook: 'https://facebook.com/momai',
        instagram: 'https://instagram.com/momai',
        twitter: 'https://twitter.com/momai'
    },
    analytics: {
        // Add your analytics tracking ID here
        googleAnalyticsId: '',
        facebookPixelId: ''
    },
    features: {
        enableNewsletter: true,
        enableTestimonials: true,
        enableVideoEmbed: true
    },
    colors: {
        primary: '#FF6B6B',
        secondary: '#88D8C0',
        dark: '#2E2E2E',
        light: '#F8F9FA'
    }
};

export default config; 