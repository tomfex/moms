const http = require('http');
const https = require('https');
const nodemailer = require('nodemailer');
const siteConfig = require('../config/site');

// Email configuration
const transporter = nodemailer.createTransport({
    host: 'smtp.hostinger.com',
    port: 587,
    secure: false,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

// Health check endpoints
const endpoints = [
    {
        url: `${siteConfig.site.url}`,
        name: 'Homepage',
        method: 'GET'
    },
    {
        url: `${siteConfig.site.url}/lead-capture`,
        name: 'Lead Capture',
        method: 'GET'
    },
    {
        url: `${siteConfig.site.url}/checkout`,
        name: 'Checkout',
        method: 'GET'
    }
];

// Check endpoint health
async function checkEndpoint(endpoint) {
    return new Promise((resolve) => {
        const protocol = endpoint.url.startsWith('https') ? https : http;
        const req = protocol.request(endpoint.url, { method: endpoint.method }, (res) => {
            const isHealthy = res.statusCode >= 200 && res.statusCode < 300;
            resolve({
                endpoint: endpoint.name,
                status: res.statusCode,
                healthy: isHealthy,
                timestamp: new Date().toISOString()
            });
        });

        req.on('error', (error) => {
            resolve({
                endpoint: endpoint.name,
                status: 'error',
                healthy: false,
                error: error.message,
                timestamp: new Date().toISOString()
            });
        });

        req.end();
    });
}

// Send email notification
async function sendNotification(subject, body) {
    try {
        await transporter.sendMail({
            from: `"Mom AI Monitor" <${siteConfig.site.email}>`,
            to: process.env.ADMIN_EMAIL,
            subject: subject,
            html: body
        });
        console.log('Notification sent successfully');
    } catch (error) {
        console.error('Failed to send notification:', error);
    }
}

// Main health check function
async function performHealthCheck() {
    console.log('Starting health check...');
    const results = await Promise.all(endpoints.map(checkEndpoint));
    const unhealthy = results.filter(result => !result.healthy);

    if (unhealthy.length > 0) {
        const subject = `🚨 Mom AI Website Issues Detected`;
        const body = `
            <h2>Website Health Check Failed</h2>
            <p>The following endpoints are experiencing issues:</p>
            <ul>
                ${unhealthy.map(result => `
                    <li>
                        <strong>${result.endpoint}</strong><br>
                        Status: ${result.status}<br>
                        Error: ${result.error || 'N/A'}<br>
                        Time: ${result.timestamp}
                    </li>
                `).join('')}
            </ul>
            <p>Please check the server logs for more details.</p>
        `;
        await sendNotification(subject, body);
    }

    // Log results
    console.log('Health check results:', results);
    return results;
}

// Run health check every 5 minutes
setInterval(performHealthCheck, 5 * 60 * 1000);

// Initial check
performHealthCheck(); 