module.exports = {
    site: {
        name: 'Mom AI',
        url: process.env.DOMAIN || 'https://mom-ai.shop',
        description: 'AI Solutions for Busy Moms',
        email: 'contact@mom-ai.shop'
    },
    pricing: {
        course: {
            amount: 50000, // €500 in cents
            currency: 'eur',
            name: 'AI for Busy Moms Course',
            description: 'Complete course with lifetime access'
        },
        coaching: {
            amount: 29700, // €297 in cents
            currency: 'eur',
            name: '1:1 Coaching Session',
            description: 'Personal coaching session'
        }
    },
    features: {
        enableNewsletter: true,
        enableTestimonials: true,
        enableVideoEmbed: true,
        enableWhatsApp: true
    },
    colors: {
        primary: '#FF6B6B',
        secondary: '#88D8C0',
        dark: '#2E2E2E',
        light: '#F8F9FA'
    }
}; 