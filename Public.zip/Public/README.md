# Mom AI Website

A modern, responsive website for Mom AI, providing AI solutions for busy moms.

## Project Structure

```
├── index.html          # Main landing page
├── css/
│   └── styles.css      # Main stylesheet
├── js/
│   └── main.js         # Main JavaScript file
├── config.js           # Website configuration
└── README.md           # Project documentation
```

## Features

- Responsive design
- Modern UI with smooth animations
- Mobile-first approach
- Optimized for performance
- Easy to customize

## Setup

1. Clone the repository
2. Update the `config.js` file with your settings
3. Add your analytics tracking IDs in the config file
4. Deploy to your hosting provider

## Customization

- Colors can be modified in the `config.js` file
- Styles can be customized in `css/styles.css`
- Add your own content in `index.html`

## Integration

The website is integrated with mom-ai.shop and can be easily connected to:
- Newsletter services
- Analytics platforms
- Social media accounts
- Payment processors

## Development

To modify the website:

1. Edit the HTML in `index.html`
2. Update styles in `css/styles.css`
3. Add functionality in `js/main.js`
4. Update configuration in `config.js`

## License

All rights reserved © Mom AI 